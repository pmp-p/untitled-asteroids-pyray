class DoublyLinkedStack:
    """
    Head will always reference the most recently added node (top of the stack)
    Tail will always reference the first node (bottom of the stack)
    """

    class Node:
        """
        Node class, where each node has a data attribute as well as stores
        references to the previous and next nodes
        """

        def __init__(self, data):
            self.data = data
            self.last = None
            self.next = None

    def __init__(self):
        self.head = None
        self.tail = None

    def push(self, data):
        """
        Add an item to the top of the stack.
        If the stack is empty, create a new node and set it as top of the stack.
        Otherwise, add a new node at the top and adjust the links.
        """
        if self.head is None:
            new_node = self.Node(data)
            self.head = new_node
            self.tail = new_node
        else:
            # If the stack isn't empty, the new node becomes the top
            new_node = self.Node(data)

            # Link the new node to the current head
            new_node.next = self.head

            # Set the current head's last pointer to the new node
            self.head.last = new_node

            self.head = new_node

    def pop(self):
        """
        Remove the most recently added item from the stack and return it.
        If the stack is empty, return None.
        """
        # Stack is empty
        if self.head is None:
            return None

        top_element = self.head.data

        # Only one item in the stack
        if self.head.next is None:
            self.head = None
            self.tail = None
            return top_element

        # More than one item in the stack
        else:
            next_head = self.head.next
            next_head.last = None
            self.head = next_head
            return top_element

    def top(self):
        """
        Return the top item of the stack without removing it.
        Return None if the stack is empty.
        """
        if self.head is None:
            return None
        return self.head.data

    def isEmpty(self):
        """
        Check if the stack is empty.
        Return True if empty, False otherwise.
        """
        return self.head is None


if __name__ == "__main__":
    doubly_linked_stack_test = DoublyLinkedStack()
    doubly_linked_stack_test.push(1)
    doubly_linked_stack_test.push(2)
    doubly_linked_stack_test.pop()
    doubly_linked_stack_test.pop()
    doubly_linked_stack_test.pop()
    print(doubly_linked_stack_test.pop())
    print(doubly_linked_stack_test.pop())
    print(doubly_linked_stack_test.pop())
    doubly_linked_stack_test.push(1)
    doubly_linked_stack_test.push(2)
    doubly_linked_stack_test.push(3)
    doubly_linked_stack_test.push(4)
    doubly_linked_stack_test.push(5)
    doubly_linked_stack_test.push(6)
    print(doubly_linked_stack_test.top())
